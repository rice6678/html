"""
def get_name():
    user_name = input("enter your name: ")
    return user_name

def get_age():
    user_age =int(input("enter your age: "))
    return user_age
"""
def get_data():
    user_name = input("enter your name: ")
    user_age =int(input("enter your age: "))
    return user_name, user_age


def print_Msg(user_name, user_age):
    if user_age<=10:
        print("Hi", user_name, user_age)
    else:
        print("hello", user_name,user_age)

def main():
    """
    user_name = get_name()
    user_age=get_age()
    """
    user_name, user_age = get_data()
    print_Msg(user_name, user_age)
   
while True:
    main()
