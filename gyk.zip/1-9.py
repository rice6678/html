import random
a=random.randint(1,50)
for i in range(4,0,-1):
    b=int(input('number'))
    if b>a:
            print('low')
    else:
            print('high')
    if a==b:
        print('correct')
        print(i*1000)
        break
        
