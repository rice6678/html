import turtle
t=turtle.Turtle()
t.speed(0)
for i in range(50):
    t.right(360/50)
    for i in range(5):
        t.forward(200)
        t.right(45)
