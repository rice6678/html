import random
while True:
    b=int(input('number'))
    a=random.randint(1,10)
    if a==b:
        print('correct')
        break
    
    
