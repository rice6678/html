import random
for i in range(5):
    s=0
    n1=random.randint(1,100)
    n2=random.randint(1,100)
    print(n1,'+',n2)
    a=int(input('number'))
    if a==(n1+n2):
        print('right')
        s=s+1
    else:
        print('wrong')
print(s)
