import random
n1=random.randint(1,10)
n2=random.randint(1,10)
a=['+','-','*']
c=random.choice(a)
e=str(n1)+c+str(n2)

b=int(input(e))



if eval(e)==b:
    print('correct')
