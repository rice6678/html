import turtle
t=turtle.Turtle()
t.circle(30)
