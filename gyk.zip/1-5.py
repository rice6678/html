import random
a=random.randint(1,5)
b=int(input('number'))
if a==b:
    print('well done')
else:
    
    if b>a:
        print('low')
    else:
        print('high')
        
    c=int(input('number'))
    
    if c==a:
        print('correct')
    else:
        print('you lose')
print(a)
