import random
f=['사과','망고','바나나','수박']
a=random.randint(0,len(f)-1)
print(f[a])
