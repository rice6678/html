import turtle
c=["yellow","red","blue"]
t=turtle.Turtle()
for j in range(3):
    x=100+j*50
    t.fillcolor(c[j])
    t.begin_fill()
    t.down()
    for i in range(4):
        t.forward(20)
        t.right(90)
    t.penup()
    t.end_fill()
    t.goto(x,0)
        
