import random
f=['i','h']
a=random.choice(f)
b=input('i or h')
if a==b:
    print('you win')
else:
    print('bad luck')
print(a)
