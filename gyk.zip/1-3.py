import random
f=['사과','망고','바나나','수박']
a=random.choice(f)
print(a)
