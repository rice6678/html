import random
import turtle
t=turtle.Turtle()
c=["red","blue","yellow","pink","purple","black","orange","green"]

for i in range(8):
    t.pencolor(random.choice(c))
    t.forward(30)
    t.right(45)
    
