a=[1,1,1,3,4,5,7,1]
b=int(input('i1'))
c=int(input('i2'))
a.insert(b,c)
for i in range(len(a)) :
    print(a[i])
