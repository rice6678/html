slist=["영어","수학","사회","과학","기술"]
for i in slist:
    print(i)
