a=int(input("숫자를 입력하시오"))

if a%2==0:
    print("짝수입니다")
else:
    print("홀수입니다")
