def f1(n1):
   s=0
   for i in range(1,n1+1):
            s=s+i
   print(s)
    
def f2(n1):

    s=0
    for i in  range(1,10):
            print(n1,'*',i,'=',n1*i)
def f3(n1):
    print(n1*4)
    print(n1**2)

def f4(n1):
    print(n1**2*3.14)
    print(n1*2)
 
def f0(k):

     f1(k)

     f2(k)


     f3(k)

     f4(k)

    
a=float(input("값을 입력하시오"))
#f0(a)

if a >=1 and a<=9:
    f1(a)
    f2(a)
    f3(a)
    f4(a)
else:
    f1(a)
    f3(a)
    f4(a)
