a=int(input("a숫자 입력"))
b=int(input("b숫자 입력"))
c=int(input("c숫자 입력"))
if a*a+b*b==c*c:
   print("직각삼각형 가능")
else:
   print(" 직각 삼각형 아님")
