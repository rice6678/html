a=int(input("초를 입력하시오"))
m = a//60
s = a %60

print(f"{m}분 {s}초입니다.")
