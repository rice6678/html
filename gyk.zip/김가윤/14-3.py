a=input('name')
b=int(input('number'))
for i in range(b):
    print(a)
