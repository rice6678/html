import turtle

colors=["red","purple","blue","beige","firebrick"]
t=turtle.Turtle()

turtle.bgcolor("black")
t.speed(0)
t.width(3)
length=10

while length<500:
    t.forward(length)
    t.pencolor(colors[length%5])
    t.right(89)
    length+=5
