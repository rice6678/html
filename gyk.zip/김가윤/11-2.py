import urllib.request
url="https://www.naver.com"
res=urllib.request.urlopen(url)
k=res.read()
len(k)
print (k[0:501].decode())
