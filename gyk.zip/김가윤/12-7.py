a= int(input('total price'))
b=int(input('how many diners'))

print('each diners have to pay',[a/b])
