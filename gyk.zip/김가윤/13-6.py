a=input('your first name')
if len(a)>=5:
    b=input('your sub name')
    c=(a+b)
    print(c.upper())
else:
    print(a.lower())
