
a=[]
while True:
    s=int(input("점수입력"))
    a.append(int(s))
    total=0
    if s==-1:
        break
    else:
        a.append(s)  

for i in range(len(a)):
    total=total+a[i]
average=total/len(a)
print(average)
