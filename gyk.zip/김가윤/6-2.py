a=input("1번 전지가 있나?(y/n)")
b=input("2번 전지가 있나?(y/n)")

if a=='y' and b=='n':
    print("직렬:전구에 불이 꺼짐")
    print("병렬:전구에 불이 켜짐")
if a=='y' and b=='y':
    print("직렬:전구에 불이 켜짐")
    print("병렬:전구에 불이 켜짐")
if a=='n' and b=='n':
    print("직렬:전구에 불이 꺼짐")
    print("병렬:전구에 불이 꺼짐")
if a=='n' and b=='y':
    print("직렬:전구에 불이 꺼짐")
    print("병렬:전구에 불이 켜짐")
