k=["80","100","70","50","90","70",80,40]
k.append(100)
s=0
for i in range(len(k)):
    s=s+int(k[i])

print(s, s/len(k))
