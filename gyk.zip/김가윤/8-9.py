import random
a=[]
s=0
while s<5:
    r=random.randint(1,50)
    if r in a:
        print(r,a)
        continue
    else:
        s=s+1
        a.append(r)

print(a)


cnt=0
for i in range(5):
    n=int(input("숫자를 입력하시오"))
    k=False
    for j in range(len(a)):
        if n==a[j]:
            k=True
            cnt=cnt+1
            break
    if k==True:
        print("ok")
    else:
        print("X")
print(a)
print(cnt*1000,"원을 주세요")
