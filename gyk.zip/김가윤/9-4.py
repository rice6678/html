import turtle

t=turtle.Turtle()

t.speed(20)

t.width(3)

length=10

color=['red','purple','blue','pink','yellow','orange','black','green','darkred','darkblue']
d = 0
while length<500:
    t.forward(length)
    t.pencolor(color[d%len(color)])
    t.right(131)
    length+=5
    d=d+1
