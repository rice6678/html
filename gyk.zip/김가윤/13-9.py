import math
x=int(input('number'))
x=math.sqrt(x)
print(x)
