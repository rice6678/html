import tkinter
def p1():
    print('가위')
def p2():
    print('바위')
def p3():
    print('보')
w=tkinter.Tk()
#e=tkinter.Entry(w)
#e.grid(row=0,column=0)
b1=tkinter.Button(w, text='가위',command=p1)
b2=tkinter.Button(w, text='바위',command=p2)
b3=tkinter.Button(w, text='보',command=p3)
b1.grid(row=0,column=0)
b2.grid(row=0,column=1)
b3.grid(row=0,column=2)
#def process():
    #print('안녕하세요?')

