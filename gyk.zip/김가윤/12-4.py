a=int(input('first'))
b=int(input('second'))
c=int(input('third'))

print((a+b)*c)
