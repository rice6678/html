a=int(input('how many days'))
print([a*24],[a*24*60],[a*24*60*60])
