v=['a','e','i','o','u']
while 1:
    a=input('somthing')
    #if a[0]=='a' or [0]=='e'  or a[0]=='i' or a[0]=='o' or a[0]=='u':

    if a[0] in v: 
        print(a+ "way")
    else:
        print(a[1: ]+a[0]+ ay)

