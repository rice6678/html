a=input('your first name')
b=input('your surname')
print('hello',[a],[b])
