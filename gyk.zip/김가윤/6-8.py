a=int(input("숫자를 입력하시오"))

if a%2==0 and a%3==0:
    print("2와3으로 나누어 떨어집니다")
