import time
for i in range(15):
    print(i)
    time.sleep(100)
