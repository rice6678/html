n1=int(input('enter the number'))
n2=int(input('enter the number'))
an1=n1//n2
an2=n1%n2
print(n1,n2,an1,an2)
