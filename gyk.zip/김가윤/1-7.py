marks=[40,70,100,80,59]
cnt=0
fail=0
s1=0
s2=0
for m in marks:
    
    if m>60:
        print (m, "합격")
        cnt=cnt+1
        s1=s1+m
    else:
        print (m,"불합격")
        fail=fail+1
        s2=s2+m
print(cnt)
print(fail)
print(s1/cnt)
print(s2/fail)
