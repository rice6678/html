s=int(input("단수를 입력하시오"))
for i in range(1,s):
    print()
    for j in range(1,s):
        print(i,"*",j,"=",i*j)


