import calendar
print (calendar.calendar(2100))
print(calender.prcal(2100))
print(calender.prmonth(2100, 9))
