

import random
cnt=1

while True:
    print(cnt)
    num= int(input('숫자를 입력하시오'))
    a=random.randint(1,20)
    print(a)
    if num==a:
        print('당첨!')
        break
    else:
        print('ㅋㅋ')
    cnt=cnt+1
