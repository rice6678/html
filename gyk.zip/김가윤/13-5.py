print(input('something').upper())
