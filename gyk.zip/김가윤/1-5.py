muzi="121130-32101123"
print('출생년도', muzi[0:2])
print('출생월', muzi[2:4])
print('출생일', muzi[4:6])

print('성별', muzi[7])
