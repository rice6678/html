a=[]


while True:
    r=input("숫자를  입력하시오")
    if r=="q":
         break
    a.append(int(r))
print(a)
s=0
for i in range(len(a)):
    s=s+a[i]
print("평균값은",s/len(a))
