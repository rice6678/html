a=int(input("첫번쨰 수를 입력하시오"))
b=int(input("두번쨰 수를 입력하시오"))

#print(a,"나누기",b,"는",a/b,"입니다")
print(f"{a}나누기{b}는{a/b}입니다.")
