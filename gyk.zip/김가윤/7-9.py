import random
cnt=0

r=random.randint(1,50)
while True:

    a=int(input("추측"))
    if a==r:
        print("맞췄습니다")
        break
    else:
    
        print("땡")
    if a<r:
        print("big")
    else:
        print("small")
        
    cnt=cnt+1
    if cnt==5:
        break

    """
print(r)

print(score)
    """
