money=int(input("money:"))
price=int(input("price:"))
print("거스름돈",(money-price))
print("500",(money-price)//500)
print("100",(money-price)%500//100)
    
