import turtle
import random

asteroids=[ ]
for i in range(10):
    a1=turtle.Turtle()
    a1.color("red")
    a1.shape("circle")
    a1.penup()
    a1.speed(0)
    a1.goto(random.randint(-300,300),random.
randint(-300,300)
    asteroids.append(a1)
