a=int(input("값을 입력"))
even=0
odd=0
for i in range(1,a+1):
    if i%2==0:
      even=even+i
    else:
      odd=odd+i
print("짝수만 더한값",even)
print("홀수만 더한값",odd)
print("전체 더한",even+odd)
