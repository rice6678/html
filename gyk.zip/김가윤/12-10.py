a=int(input('over 100'))
b=int(input('under10'))

print('the',[b], 'go into', [a], [a/b],'time')
