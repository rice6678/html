data= ["가위", "바위", "보"]
import random
a=random.randint(0,2)
print(data[a])
