heros=[]

for i in range(5):
    name = input("영웅들의 이름을 입력하시오")
    heros.append(name)
for i in heros:
    print(i,end="")
