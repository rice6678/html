def get_sum(a,b):
    s=0
    for i in range(a,b+1):
        s=s+i
    print(s)

def judge(n):

    if n%2==0:
        print("짝수")
    else:
        print("홀수")

        
while True:
    """
    n1=int(input("시작값"))
    n2=int(input("끝값"))
    get_sum(n1,n2)
    """
    n=int(input("입력하시오"))
    judge(n)

