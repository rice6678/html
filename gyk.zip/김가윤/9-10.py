import turtle
t=turtle.Turtle()
for i in range(8):
    t.forward(100)
    t.right(90)
    t.forward(30)
    t.right(90)
    t.forward(100)
    t.left(90)
    t.forward(30)
    t.left(90)
  
