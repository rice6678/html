import random
a=[0,0,0,0,0,0]
n = 100000000
for i in range(n):
    r=random.randint(0,5)
    a[r]=a[r]+1
print(a)

for i in range(6):
    print(i+1,a[i]/n)
