import turtle
t=turtle.Turtle()
t.shape("circle")
radius=int(input("원의 반지름을 입력하시오"))
t.up()
t.goto(0,0)
t.down()
t.circle(radius)
t.up()
t.goto(100,0)
t.down()
t.circle(radius+20)
t.up()
t.goto(200,0)
t.down()
t.circle(radius+40)


           



