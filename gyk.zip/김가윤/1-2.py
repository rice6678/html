a=91
b=82
c=75
d=94
print(a+b+c+d)
print( (a+b+c+d)/4)
sum=a+b+c+d
print(sum/4)
