a=input('your first name')
b=input('your subname')
c = a + ' ' + b

print(c, len(c))
