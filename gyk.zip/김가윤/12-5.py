a=int(input('how many slices'))
b=int(input('how many slices you ate'))
print ('you have', [a], 'slices you ate', [b], 'slices', [a-b] ,'slices left')
