for i in range (2,101):
    if i%2==0:
        print(i)
