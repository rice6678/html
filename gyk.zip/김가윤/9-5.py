import turtle
t=turtle.Turtle()
a=[[100,200,200,'blue'],[0,1,2,'red'],[3,4,5,'black'],[6,7,8,'pink'],[9,10,11,'yellow']]

for i in range(len(a)):
    t.up()
    t.goto(a[i][0],a[i][1])
    t.down()
    t.pencolor(a[i][3])
    t.begin_fill()
    for j in range(4):
        t.forward(a[i][2])
        t.left(90)
    t.end_fill()
        
