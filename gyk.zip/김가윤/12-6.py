a=input('your name')
n=int(input('your age'))
print([a],'next birthday you will be', [n+1])
