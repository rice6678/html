f=open("11-5.txt",'r')
r=f.readlines()
print(r)
f.close()
