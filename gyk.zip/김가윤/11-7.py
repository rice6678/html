
a=int(input('숫자'))
f=open(f'가윤{a}.txt','w')


for i in range(1,10):
    #t=str(a)+'*'+str(i)+'='+str(i*a)
    t=f'{a}*{i}={a*i}'
    f.write(t+'\n')
f.close()

    
