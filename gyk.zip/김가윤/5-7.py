a=int(input("나이를  입력하시오"))
b=int(input("키를 입력하시오"))
if a>=10 and b>=110:
    print("입장 가능합니다")
else:
    print("입장 할수 없습니다")
