a=1
b=2
print(a+b)
c='life is too short, you need python'
