import turtle

def hexagon():
    for i in range(6):
        t.forward(100)
        t.left(360/6)
t=turtle.Turtle()

for i in range(100):
    hexagon()
    t.forward(100)
    t.right(70)
