a=input('your first name')
b=input('your sub name')
c=a+ ' ' + b
print(c.title())
