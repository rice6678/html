f1 = open('input.txt','r')
data=f1.readlines()
f1.close()
print(data)
k=data[0].split()

f2=open('result.txt','w')
for i in range(len(k)):
    for j in range(1,10):
        r = int(k[i]) * j
        t=f'{k[i]}*{j}={r}'
        f2.write(t+'\n')
    f2.write('\n')
f2.close()




"""
a=int(input('숫자'))
f=open(f'가윤{a}.txt','w')


for i in range(1,10):
    #t=str(a)+'*'+str(i)+'='+str(i*a)
    t=f'{a}*{i}={a*i}'
    f.write(t+'\n')
f.close()
"""
