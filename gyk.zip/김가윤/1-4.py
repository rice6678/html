m1=input("원화:")
m2=input("달러")
if int(m1) >=3000 or int(m2)>=3:
 print("택시를 타고 가라")
else:
    print (" 걸어가라")
