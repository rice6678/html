def bmi(h,w):
    return w/(h*h)

def print_result(b):
    if b<18.5:
        print('저체중')
    elif b>=18.5 and b<=22.9:
        print('정상')
    elif b>=23 and b<=24.9:
        print('과체중')
    elif b>=25 and b<=29.9:
        print('경도비만')
    else:
        print('고도비만')


while True:
    h=float(input('height'))
    w=float(input('weight'))

    result=bmi(h,w)
    print_result(result)
