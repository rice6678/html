while True:
    a=int(input('number'))
    if a>=1 and a<=12:
        for i in range(1,13):
            n=i*a
            print(i,'*',a,'=',n)
    else:
        print('error')
        
