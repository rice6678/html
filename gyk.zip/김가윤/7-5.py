import random

score=0
cnt=0
r=int(input("문 갯수를 입력하시오"))
n=random.randint(1,j)

while True:
    cnt=cnt+1
                
    a=int(input("문을 고르시오"))
    if a==r:
        score=score+100
        print('천원을 주세요')
        break
    else:
        score=score-10
        if a>r:
            print('BIG')
        else:
            print("small")

    if cnt==3:
        print("fail")
        breakpoint
    
print(score)
