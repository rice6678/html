a=int(input("첫번쨰 숫자 입력"))
b=int(input("두번쨰 숫자 입력"))
c=int(input("세번쨰 숫자 입력"))
print(a,b,c,"의 평균은",(a+b+c)/3,"입니다")
