import time
n=int(input('number'))
for i in range(50, n-1,-1):
    time.sleep(0.001)
    print(i)
