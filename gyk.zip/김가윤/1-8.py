marks=[90, 25, 67, 45, 80, 48, 59, 58, 70]
sum=0
cnt=0

for m in marks:
    #print(m)
    sum=sum+m
    #print(sum)
    cnt=cnt+1 

print(sum)
print("총합", sum)

print("개수",len(marks))
  
print(cnt)
