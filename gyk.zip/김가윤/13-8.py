x=float(input('number'))
print (x*2)
