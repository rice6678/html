a=int(input("초를입력하시오"))
m=a//60
s=a%60
n=m//60

print(f"{n}시{m}분{s}초입니다.")
      
