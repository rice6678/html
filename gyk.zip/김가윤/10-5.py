s=input("나라")
nation=["대한민국","일본","미국"]
city=["서울","도쿄","워싱턴dc"]

a=nation.index(s)
print(city[a])
