def exchange(m,c):
    if c in country_list:
        i=country_list.index(c)

        r = m / rate[i]

        print(r, unit[i])
        
    else:
        print("x")
        return
    


    
country_list=["미국","중국","일본","유럽"]
unit=["달러","위엔","앤","유럽"]
rate=[1160.2,179.25,10.61,1371.19]

m=int(input('원화'))
c=input("나라")

exchange(m, c)
