

f=open('11-5(txt)','w')
f.write('유비,85,76,87')
f.close()
