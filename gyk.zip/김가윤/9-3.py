import random


r=[]
while len(r)<5:
 
    n=random.randint(1,50)
    if n in r:
        continue
    else:
        r.append(n)

v = 0
for i in range(5):
    s=int(input("숫자를 입력하시오"))
    if s in r:
        print("1000")
        v=v+1000
print(v)

print(r)
