import random

d={1:'가위',2:'바위',3:'보'}
m={'가위':'보','바위':'가위','보':'바위'}
my_win=0
com_win=0
draw=0
for i in range(1,10):
    r=random.randint(1,3)
    #print(d[r])
    com=d[r]
    my=input('가위,바위,보')
    if my==com:
        print('비김')
        draw=draw+1
    elif m[my]==com:
        print('승리')
        my_win=my_win+1
    else:
        print('패배')
        com_win=com_win+1
    print(my_win,com_win,draw)
