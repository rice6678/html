p=["오버워치","롤", "스타크래프트", "마인크래프트", "브롤스타즈"]
number=0
for s in p :
    number= number+1
    print(number, s)
    
