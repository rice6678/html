letters=['a','b','c','d','e','f']
print(letters[0:3])
print(letters[ :3])
