print('1) square')
print('2)triangle')
print(" enter a number'')
      n=input('1,2 choose')
