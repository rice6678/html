print("문장을 입력하세요")
a=input()
print(a[-1:-(len(a)+1):-1])
