a=int(input("점수를 입력하시오"))
if a>=60 :
    print("합격입니다")
else:
    print(" 불합격입니다")
