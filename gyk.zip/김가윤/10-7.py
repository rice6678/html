def p(name,age):
    print("대한민국")
    print("세종시 어진동")
    print(name)
    print(age)
a=["홍길동","김가윤","김도연"]
b=[25,30,35]
for i in range(len(a)):
    p(a[i],b[i])
