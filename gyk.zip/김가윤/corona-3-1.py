import requests
#url= "https://www.naver.com/"
url= "http://ncov.mohw.go.kr/"
res=requests.get(url)
f= open("temp2.html", "w", encoding="utf-8")
f.write(res.text)
f.close()

import bs4
soup= bs4.BeautifulSoup(res.text, "html.parser")
items= soup.find_all("span",{"class":"num"})
for i in items:
    print(i.text)
