s=0
for i in range (1,11,1):
     s=s+i
     print(i,s)
print(s)
