a=[78,69,65,86,72,45,92,61]
s=0
for i in a:
    s = s + i

print(s)
print(s/len(a))
