import random
print(random.randrange(4))
