data=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
import random
cnt=10
success = 0

while True:
    print(cnt, "번 남았습니다.")
    if cnt==0:
        break
    
    num=int(input("숫자를 입력하세요"))
    a=random.randint(0,19)
    print(data[a])

    if num==data[a]:
        print("당첨!")
        success=success+1
    else:
        print("ㅋㅋ")
    cnt=cnt-1

print(success,"번 맞춤")
