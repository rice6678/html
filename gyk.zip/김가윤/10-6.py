def z():
    s=int(input("온도"))
    c=float(input("현재수증기량"))

    f=[0,10,20,30]
    g=[4.8,9.4,17.3,30.4]

    a=f.index(s)


    print(g[a])
    print(c/g[a]*100)
