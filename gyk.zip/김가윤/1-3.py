n= input("주민번호를 입력하세요:")
print("출생년도", n[0:2])
print("출생월",n[2:4])
print('출생일',n[4:6])


print('성별',n[7])
if n[7] == '3':
    print('남자')
else:
    print('여자')  
