import random

r=[]
while len(r)<5:
 
    n=random.randint(1,50)
    if n in r:
       
        continue
    else:
        r.append(n)

for i in range(5):
    n = int(input("값을 입력하시오"))
    if n in r:
        print("ok,2000")
        break
    else:
        print("no")

print(r)
