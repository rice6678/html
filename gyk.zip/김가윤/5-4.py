a=int(input("언어를 입력하시오(1:한국어, 2:영어, 3:프랑스, 4:독어"))
if a==1:
    print("안녕하세요")
if a==2:
    print("hello")

if a==3:
    print("Bonjour")
if a==4:
    print("guten morgen")
