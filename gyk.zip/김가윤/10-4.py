import turtle
t=turtle.Turtle()

color = ['yellow','green','orange','red','blue']

for j in range(5):
    t.color(color[j])
    for i in range(5):
        t.forward(100)
        t.right(72)
    t.left(72)
