import random
score=5000
cnt=0

r=random.randint(1,300)
while True:
    cnt=cnt+1
    a=int(input("추측"))
    if a==r:
        print("맞췄습니다")
        break
    else:
        score=score-1000
        print("땡")
        if a<r:
            print('BIG')
        else:
            print("small")
    if cnt==5:
        break
print(r)

print(score)

  
