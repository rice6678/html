import random
f=open('SAM.txt','r',encoding='utf-8')
data=f.readlines()
for i in range(len(data)):
    data[i]=data[i].split()
    if i>0:
        for j in range(1,len(data[0])):
            data[i][j]=int(data[i][j])
        
def search(name):
    for i in range(len(data)):
         if data[i][0]==name:
                return i
            
def show(num):
    for i in range(len(data[0])):
                   print(data[0][i],data[num][i])

def pick(num):
    for i in range(num):
        r=random.randint(1,len(data))
        show(r)
        print()
                   
def find_min():
    max_total=999
    max_num=0
    for i in range(1, len(data)):
        temp=data[i][1]+data[i][2]+data[i][3]
        #print(temp)
        if temp<max_total:
            max_total=temp
            max_num=i        
    show(max_num)
    
while True:
    name=input("이름입력")
    num=search(name)
    show(num)
