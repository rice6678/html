import random
a=random.randrange(4)+1
print(a)
if a==1 or a==3:
   print("man")
if a==2 or a==4:
   print("woman")
