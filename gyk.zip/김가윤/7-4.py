import random
cnt=0
score=0
n=random.randint(1,50)

while True:
    cnt=cnt+1
    i=int(input("방 번호를 입력하시오"))
    if i==n:
        print("success")
        score=score+100
        break
    else:
        score=score-10
        print("fail")

    if cnt==3:
        break

print(score)
    

    
    
