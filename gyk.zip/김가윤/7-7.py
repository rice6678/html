s=0
a=int(input("숫자를 입력하시오"))
c=0
for i in range(1,a+1):
    if i%3==0:
        s=s+i
        c=c+1

print(s,c)
