data= [i for i in range (1,45)]
import random
for i in range(3):
    
    num= int(input('숫자를 입력하시오'))
    a=random. randint(1,20)
    print (data[a])
    if num==data[a]:
        print('당첨!')
    else:
        print('ㅋㅋ')
        
