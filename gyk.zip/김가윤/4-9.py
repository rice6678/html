r=int(input("r:"))
h=int(input("h:"))

print("원기둥의 부피",(r*r*h*3.141592))

