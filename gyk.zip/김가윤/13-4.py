a=input('something')
b=int(input('start'))
c=int(input('end'))
print(a[b:c])
