a=input('your name')
print(len(a))
