import turtle
t=turtle.Turtle()
c=["red","pink","blue","green","yellow"]
import random
for i in range(10):
        r=random.randint(1,100)
        x=random.randint(-100,100)
        y=random.randint(-100,100)

        t.color(c[i%len(c)])
        t.circle(r)
        t.up()
        t.goto(x,y)
        t.down()
