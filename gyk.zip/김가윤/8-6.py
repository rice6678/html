import random
h=[]
for i in range(5):
    a=random.randint(1,50)
    h.append(a)
g=0
for i in range(5):
    if h[i]%2==0:
        print(h[i])
        g=g+h[i]
    
print(g)
    

