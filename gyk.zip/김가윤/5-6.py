a=int(input("숫자를 입력하시오"))
if a==1:
      print("월")
elif a==2:
      print("화")
elif a==3:
      print("수")
elif a==4:
      print("목")
elif a==5:
      print("금")
else:
      print("주말입니다")

