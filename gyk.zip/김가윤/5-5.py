a=int(input("나이를 입력하시오"))
if a>=15:
    print("영화 관람 가능")
else:
    print("영화를 관람할수 없습니다")
