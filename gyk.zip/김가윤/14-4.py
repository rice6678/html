a=input('name')
b=int(input('number'))
for j in range(b):
 for i in range(len(a)):
    print(a[i])
