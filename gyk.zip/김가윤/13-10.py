import math
r=float(input('radius'))
d=float(input('depth'))
x=(math.pi*(r*2))
v=x*d
print(round(v,3))
