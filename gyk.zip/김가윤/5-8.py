a=int(input("정수를 입력하시오"))
if a>0:
   print("양수")
elif a<0:
   print("음수")
else :
   print("0")
