s=[]
a=0
for i in range(5):
    k=int(input("점수를 입력하시오"))
    s.append(k)
    a=a+s[i]

print(a,a/len(s))
if (a/len(s))>=90:
    print("A")
if (a/len(s))>=80 and (a/len(s))< 90:
    print("B")
if (a/len(s))>=70 and (a/len(s))<80:
    print("C")
if (a/len(s))<=60 and (a/len(s))<70:
    print("D")

    
