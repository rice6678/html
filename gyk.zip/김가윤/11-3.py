import time
import turtle
def p(n,l):
    for i in range(n):
        t.left(360/n)
        t.forward(l)
    time.sleep(5)
    t.clear()
t=turtle.Turtle()

    
while True:
    n=int(input('n'))
    l=int(input("l"))
    p(n,l)
