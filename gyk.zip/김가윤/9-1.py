import random

r=[]
while len(r)<5:
    print(r)
    n=random.randint(1,50)
    if n in r:
        print(n)
        continue
    else:
        r.append(n)

print(r)
