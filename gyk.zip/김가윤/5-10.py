import turtle
t=turtle.Turtle()
t.shape("turtle")

t. penup()
t.goto(100,100)
t.write("입력된 정수는 양의 정수입니다")
t.goto(100,0)
t.write("입력된 정수는 0입니다")
t.goto(100,-100)
t.write("입력된 정수는 음수입니다")

while True:
    t.goto(0,0)
    t.pendown()
    s=turtle.textinput("크크루삥뽕" ,"숫자를 입력하시오")
    s = int(s)

    if s>0:
      t.goto(100,100)
    if s<0:
      t.goto(100,-100)
    if s==0:
      t.goto(100,0)
