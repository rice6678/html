
a=int(input('how many kilogram'))
print([a*2.204],'pound')
