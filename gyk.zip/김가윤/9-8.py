import turtle
t=turtle.Turtle()
c=["red","pink","blue","green","yellow"]
t.shape("turtle")

for j in range(36):
    t.color(c[j%len(c)])
    for i in range(5):
        t.forward(150)
        t.right(144)
    t.left(10)
