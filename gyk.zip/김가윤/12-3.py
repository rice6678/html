print('what do you call a bear with no teeath. \n gummy bear')
