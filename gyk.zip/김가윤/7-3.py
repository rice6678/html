import random

score=0
cnt=0
j=int(input("문 갯수를 입력하시오"))
n=random.randint(1,j)

while True:
    cnt=cnt+1
                
    i=int(input("문을 고르시오"))
    if i==n:
        score=score+100
        print('천원을 주세요')
        break
    else:
        score=score-10
        if n>i:
            print('BIG')
        else:
            print("small")

    if cnt==3:
        print("fail")
        break
    
print(score)
