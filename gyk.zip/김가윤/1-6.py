test_list="this is a test"

for i in test_list :

  print(i)


