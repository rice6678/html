a= int(input("년을 입력하시오"))

if a%400==0: 
    print("윤년")
if a%4==0: 
    print("윤년")
elif a%100!=0:
    print("평년")
else:
    print("평년")
    
