import random
s=0
for i in range(10):
    a=random.randint(2,10)
    b=random.randint(2,10)
    while True:
        print(a,'*',b,'=', end=' ')
        c=int(input())
        if c==a*b:
            print(correct)
            break
        else:
            print(wrong)    c
        
