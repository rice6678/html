import turtle
t=turtle.Turtle()
for i in range(3):
    t.forward(50)
    t.right(120)
