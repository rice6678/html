
def temp():
    a=1
    b=2
    c=3
    d=a+b+c
    return a,b,c,d
k=temp()
