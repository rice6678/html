def num_input():
    num=int(input('the number'))
    return num

def num_count(num):
    s=0
    for i in range(1,num+1):
        s=s+i
        print(s)
while True:
    a= num_input()
    num_count(a)
