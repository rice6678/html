import random

def comp_num():
    n1=int(input('number1'))
    n2=int(input('number2'))
    cn= random.randint(n1,n2)
    return cn

def guess_num():
    guess=int(input('what is the number?'))
    return guess

def check_num(cn,guess):

    match = False
    for i in range(5):
        if cn==guess:
            print('correct')
            match=True
            break
        elif cn>guess:
            print('high')
            guess=guess_num()
        else:
            print('low')
            guess=guess_num()


    if  match==True:
        print('2000')
    else:
        print('lose')
        print(cn)

c=comp_num()
g=guess_num()
check_num(c, g)


    
